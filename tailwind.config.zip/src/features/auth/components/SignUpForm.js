import React, { useState } from 'react';
import { Form, Button, Container, Row, Col } from 'react-bootstrap';

const SignUp = () => {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: ''
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate(formData);
    if (Object.keys(validationErrors).length === 0) {
      // Handle form submission here
      console.log('Form submitted successfully:', formData);
    } else {
      setErrors(validationErrors);
    }
  };

  const validate = (data) => {
    const errors = {};
    if (!data.username.trim()) {
      errors.username = 'Username is required';
    }
    if (!/\S+@\S+\.\S+/.test(data.email)) {
      errors.email = 'Email address is invalid';
    }
    if (data.password.length < 6) {
      errors.password = 'Password must be at least 6 characters long';
    }
    if (data.password !== data.confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
    }
    return errors;
  };

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', backgroundColor: '#80060c' }}>
      <Container>
        <Row className="justify-content-center align-items-center">
          <Col span={12} sm={6} style={{ width: '350px' }}>
            <div className="shadow-lg bg-white rounded-3 p-3">
              <h2 className="text-center">Sign Up</h2>
              <Form onSubmit={handleSubmit}>
                <Form.Group controlId="username">
                  <Form.Label>Username</Form.Label>
                  <Form.Control
                    type="text"
                    name="username"
                    value={formData.username}
                    onChange={handleChange}
                    isInvalid={!!errors.username}
                  />
                  <Form.Control.Feedback type="invalid">{errors.username}</Form.Control.Feedback>
                </Form.Group>

                <Form.Group controlId="email">
                  <Form.Label>Email address</Form.Label>
                  <Form.Control
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    isInvalid={!!errors.email}
                  />
                  <Form.Control.Feedback type="invalid">{errors.email}</Form.Control.Feedback>
                </Form.Group>

                <Form.Group controlId="password">
                  <Form.Label>Password</Form.Label>
                  <Form.Control
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    isInvalid={!!errors.password}
                  />
                  <Form.Control.Feedback type="invalid">{errors.password}</Form.Control.Feedback>
                </Form.Group>

                <Form.Group controlId="confirmPassword">
                  <Form.Label>Confirm Password</Form.Label>
                  <Form.Control
                    type="password"
                    name="confirmPassword"
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    isInvalid={!!errors.confirmPassword}
                  />
                  <Form.Control.Feedback type="invalid">{errors.confirmPassword}</Form.Control.Feedback>
                </Form.Group>

                <div className='d-flex justify-content-center mt-3'>
                  <Button variant="primary" type="submit" className="w-100">
                    Sign Up
                  </Button>
                </div>
              </Form>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default SignUp;











// import React, { useRef } from 'react';
// // import { useCreateUserWithEmailAndPassword } from 'react-firebase-hooks/auth';
// // import { auth } from '../../../firebase';
// import { Link, Navigate } from 'react-router-dom';
// import Toastr from '../../../components/Toastr';
// import { Button, Container, Form } from 'react-bootstrap';

// const SignUpForm = () => {
//   // const [createUserWithEmailAndPassword, user, loading, error] =
//   //   useCreateUserWithEmailAndPassword(auth);
//   // const emailRef = useRef();
//   // const pwRef = useRef();

//   // const handleSignUp = (e) => {
//   //   e.preventDefault();
//   //   const email = emailRef.current.value.trim();
//   //   const password = pwRef.current.value.trim();
//   //   if (email && password) {
//   //     createUserWithEmailAndPassword(email, password);
//   //   }
//   // };
//   // console.log(user, loading, error);

//   return (
//     <>
//       {/* {user && <Navigate to="/" replace />}
//       {error && <Toastr message={error.message} />} */}
//       <Container
//         fluid
//         className="d-flex align-items-center justify-content-center"
//         style={{ minHeight: '100vh', backgroundColor: 'var(--bs-blue)' }}
//       >
//         <Form
//           // onSubmit={handleSignUp}
//           // className="bg-light d-flex flex-column w-75 gap-3 border rounded p-3"
//           // style={{ minWidth: '300px', maxWidth: '400px' }}
//         >
//           <h2 className="text-center">Join Now</h2>
//           <Form.Group controlId="Email">
//             <Form.Label>Email</Form.Label>
//             <Form.Control
//               type="email"
//               placeholder="Email address"
//               // ref={emailRef}
//               required
//             />
//           </Form.Group>
//           <Form.Group controlId="Password">
//             <Form.Label>Password</Form.Label>
//             <Form.Control
//               type="password"
//               placeholder="Password"
//               // ref={pwRef}
//               required
//             />
//           </Form.Group>
//           <Form.Check
//             type="checkbox"
//             id="agree-terms"
//             label="Agree to Terms and Conditions"
//             required
//           />
//           <Button type="submit">Sign Up</Button>
//           <p className="text-center border-top pt-1">
//             Already a user? <Link to="/account/login">LOG IN</Link>
//           </p>
//         </Form>
//       </Container>
//     </>
//   );
// };

// export default SignUpForm;

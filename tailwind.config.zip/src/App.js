import { useState } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import MobileHeader from './components/MobileHeader.js';
import Sidebar from './components/Sidebar.js';
// import PlayerBar5 from './pages/PlayerBar5.js';
import Home from './pages/Home.js';
import Leaderboard from './pages/Leaderboard.js';
import PlayAI from './pages/PlayAI.js';
import PlayOnline from './pages/PlayOnline.js';
import PlaySolo from './pages/PlaySolo.js';
import Puzzle from './pages/Puzzle';
import Practice from './pages/Practice.js';
import Play10Amount50 from './pages/Play10Amount50.js';
import PlayWithOnline from './pages/PlayWithOnline.js';
import Play5Amount from './pages/Play5Amount.js';
import { LoginForm, SignUpForm } from './features/auth/index.js';
import ForgetSection from './Forget/ForgetSection.js';
import Deposit from './pages/deposit.js';
import Kyc from './pages/kyc.js';
import Dashboardheader from './Dashboard-Component/dashboardheader.js';
import Kycform from './Dashboard-Component/Kycform.js';

function App() {
  const location = useLocation();
  const [sidebarDisplay, setSidebarDisplay] = useState(
    window.innerWidth > 768 || location.pathname === '/'
  );

  return (
    <div className="App">
      {location.pathname !== '/Dashboardheader' && sidebarDisplay && <Sidebar show={setSidebarDisplay} />}

      <div className="w-100">
        <MobileHeader showSidebar={setSidebarDisplay} />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/play/online" element={<PlayOnline />} />
          <Route path="/practice" element={<Practice />} />
          <Route path="/PlayWithOnline" element={<PlayWithOnline />} />
          <Route path="/Play10Amount50" element={<Play10Amount50 />} />
          <Route path="/Play5Amount" element={<Play5Amount />} />
          <Route path="/practice/vsai" element={<PlayAI />} />
          <Route path="/practice/solo" element={<PlaySolo />} />
          <Route path="/puzzle" element={<Puzzle />} />
          <Route path="/leaderboard" element={<Leaderboard />} />
          <Route path='/Deposit' element={<Deposit />} />
          <Route path='/Kyc' element={<Kyc />} />
          <Route path='/Dashboardheader' element={<Dashboardheader />} />
          <Route path='/Kycform' element={<Kycform />} />
          <Route path="/account/">
            <Route path="login" element={<LoginForm />} />
            <Route path="signup" element={<SignUpForm />} />
          </Route>
          <Route path='/forget' element={<ForgetSection />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
